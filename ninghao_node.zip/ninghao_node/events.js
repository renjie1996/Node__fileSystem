//模块引入,EventEmitter对象,Emitter发射的意思，事件发生器
const EventEmitter = require('events');
const fs = require('fs');
//class关键字，ES6才有的class类,实现了面向对象
//extends继承具有了事件触发的功能

class Player extends EventEmitter{}

//实例化类
let player = new Player();

// 注册监听事件，继承得来具有on绑定功能方法
// 可以注册自己的事件，events对象的神奇


//传第二个参数
// player.once('play',(track)=>{
//     console.log(`正在播放:《${track}》`);
// })
player.on('play',(track)=>{
    console.log(`正在播放:《${track}》`);
})

const music = [];
music.push('光辉岁月');
music.push('海阔天空');

music.map(musicName=>{
    player.emit('play',musicName);
    fs.appendFile('logs/hello.log',`${musicName} \n`,(error)=>{
    if(error){
        console.log(JSON.stringify(error));
    } else {
        console.log('成功写入');
    }
})

})


//触发事件，使用emit()订阅发射事件
// player.emit('play','光辉岁月');
// player.emit('play','海阔天空');




