const fs = require('fs');

//非空不能删


fs.readdirSync('dir').map((file)=>{
    fs.unlink(`dir/${file}`,(error)=>{
        if(error){
            console.log(error);
        }else{
            console.log(`成功删除了文件：${file}`);
        }
    })
})
// fs.readdirSync('dir').map((file) => {
//         fs.unlink(`dir/${file}`, (error) => {
//             if (error) {
//                 console.log(error);
//             } else {
//                 console.log(`成功删除了文件：${file}`);
//             }
//         })
//     })

fs.rmdir('dir',error=>{
    if(error){
        console.log(error);
    } else{
        console.log("成功删除目录");
    }
})

//两件事 1.删除文件夹 2.清空文件夹内部

//fs.readdirSync同步操作，如果不使用这个，同步就没有时间等报错，这个异步即可

