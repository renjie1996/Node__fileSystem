//filesystem
const fs = require('fs');

//打开
fs.stat('events.js',(error,stats)=>{
    //打开到阅读它，先把错误展示
    if(error){
        //发生错误
        //文件异常，不存在，路径错误，死机，IO忙不响应
        console.log(error);
    } else{
        console.log(stats);
        console.log(`文件：${stats.isFile()?'是':'否'}`);
        console.log(`文件夹：${stats.isDirectory()?'是':'否'}`);
    }
})

//构建文件夹
//错误JSON化
// fs.mkdir('logs',(error)=>{
//     if(error){
//         console.log(JSON.stringify(error));
//     }else{
//         console.log('成功创建目录：logs');
//     }
// })

//创建文件
//log日志后缀名
fs.writeFile('logs/hello.log','hello ~ \n',(error)=>{
    if(error){
        console.log(JSON.stringify(error));
    } else {
        console.log('成功写入');
    }
})