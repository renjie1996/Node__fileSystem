const fs = require('fs');
const player = require('events');
const writeContent = ``;

fs.writeFile('logs/hello.log',writeContent,(error)=>{
    if(error){
        console.log(JSON.stringify(error));
    } else {
        console.log('成功写入');
    }
})