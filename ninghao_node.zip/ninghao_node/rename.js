const fs = require('fs');

fs.rename('logs/hello.log','logs/geeting.log',(error)=>{
    if(error){
        console.log(error);
    } else{
        console.log('重命名成功');
    }
})
