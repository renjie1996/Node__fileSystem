const fs = require('fs');

//readdir
fs.readdir('logs',(error,files)=>{
    if(error){
        console.log(error);
    } else{
        console.log(files);
    }
})
