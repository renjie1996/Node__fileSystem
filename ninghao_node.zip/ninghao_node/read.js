const fs = require('fs');
// 'binnary'默认的二进制流 
fs.readFile('logs/hello.log','utf-8',(error,data)=>{
    if(error){
        console.log(error);
    }else{
        //二进制流
        console.log(data);
        // console.log(data.toString());

    }
})